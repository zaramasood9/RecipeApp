import mongoose from "mongoose";
const RecipeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  duration: {
    type: String,
    required: true,
  },
  rating: {
    type: String,
    required: true,
  },
  flavor: {
    type: String,
    required: true,
  },
  desc: {
    type: String,
    required: true,
  },
 
});

export default mongoose.model("Recipe", RecipeSchema)