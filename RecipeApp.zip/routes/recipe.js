import express from "express";
// import {
//   countByCity,
//   countByType,
//   createHotel,
//   deleteHotel,
//   getHotel,
//   getHotelRooms,
//   getHotels,
//   updateHotel,
// } from "../controllers/hotel.js";
import Recipe from "../models/Recipe.js";
import {verifyAdmin} from "../utils/verifyToken.js"
import { createRecipe } from "../controllers/recipe.js";

const router = express.Router();

//CREATE
router.post("/", createRecipe);
  

//CREATE POST
// router.post("/", async (req,res)=>{
  
//   const newRecipe = new Recipe(req.body)
  
//   try{
//     const savedRecipe = await newRecipe.save()
//     res.status(200).json(savedRecipe)

//   }catch(err){
//     res.status(500).json(err)
//   }
// })


//CREATE PUT
// router.put("/:id", async (req,res)=>{
  
//   //const newRecipe = new Recipe(req.body)
  
//   try{
//     const updatedRecipe = await Recipe.findByIdAndUpdate(req.params.id, { $set: req.body})
//     res.status(200).json(updatedRecipe)

//   }catch(err){
//     res.status(500).json(err)
//   }
// })


//UPDATE
router.put("/:id", updateRecipe);

//DELETE
// router.delete("/:id", async (req,res)=>{
  
//   //const newRecipe = new Recipe(req.body)
  
//   try{
//     await Recipe.findByIdAndDelete(req.params.id)
//     res.status(200).json("Recipe has been deleted.");
//   }catch(err){
//     res.status(500).json(err)
//   }
// })

router.delete("/:id", deleteRecipe);

//GET
// router.get("/:id", async (req,res)=>{
//   try{
//     const recipe = await Recipe.findByID(req.params.id)
//     res.status(200).json(recipe)
//   }catch(err){
//     res.status(500).json(err)
//   }
// })

router.get("/:id", getHotel);

// //GET ALL
// router.post("/", async (req,res)=>{
//   try{
//     const recipies = await Recipe.find()
//     res.status(200).json(recipies)

//   }catch(err){
//     res.status(500).json(err)
//   }
// })

router.get("/", getHotels);


export default router;