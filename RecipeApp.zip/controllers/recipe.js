import Recipe from "../models/Recipe.js";
import Ingredient from "../models/Ingredient.js";

export const createRecipe = async (req, res, next) => {
   const newRecipe = new Recipe(req.body);

  try {
    const savedRecipe = await newRecipe.save();
    res.status(200).json(savedRecipe);
  } catch (err) {
    next(err);
  }
};
export const updatedRecipe = async (req, res, next) => {
  try {
    const updatedRecipe = await Hotel.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    res.status(200).json(updatedRecipe);
  } catch (err) {
    next(err);
  }
};
export const deleteRecipe = async (req, res, next) => {
  try {
    await Recipe.findByIdAndDelete(req.params.id);
    res.status(200).json("Recipe has been deleted.");
  } catch (err) {
    next(err);
  }
};
export const getRecipe = async (req, res, next) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    res.status(200).json(recipe);
  } catch (err) {
    next(err);
  }
};
export const getRecipies = async (req, res, next) => {
  const { min, max, ...others } = req.query;
  try {
    const recipies = await Recipe.find({
      ...others,
    }).limit(req.query.limit);
    res.status(200).json(recipies);
  } catch (err) {
    next(err);
  }
};
