import Ingredient from "../models/Ingredient.js";
import Recipe from "../models/Recipe.js";
import { createError } from "../utils/error.js";
import Ingredient from "../models/Ingredient.js";

export const createIngredient = async (req, res, next) => {
  const RecipeId = req.params.Recipeid;
  const newIngredient = new Ingredient(req.body);

  try {
    const savedIngredient = await newIngredient.save();
    try {
      await Recipe.findByIdAndUpdate(IngredientId, {
        $push: { ingredients: savedIngredient._id },
      });
    } catch (err) {
      next(err);
    }
    res.status(200).json(savedIngredient);
  } catch (err) {
    next(err);
  }
};

export const updateIngredient = async (req, res, next) => {
  try {
    const updateIngredient = await Ingredient.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    res.status(200).json(updateIngredient);
  } catch (err) {
    next(err);
  }
};

export const deleteIngredient = async (req, res, next) => {
  const IngredientIdId = req.params.Ingredientid;
  try {
    await Ingredient.findByIdAndDelete(req.params.id);
    try {
      await Recipe.findByIdAndUpdate(IngredientIdId, {
        $pull: { ingredients: req.params.id },
      });
    } catch (err) {
      next(err);
    }
    res.status(200).json("Ingredient has been deleted.");
  } catch (err) {
    next(err);
  }
};
export const getIngredient = async (req, res, next) => {
  try {
    const ingredient = await Ingredient.findById(req.params.id);
    res.status(200).json(ingredient);
  } catch (err) {
    next(err);
  }
};
export const getIngredients = async (req, res, next) => {
  try {
    const ingredients = await Ingredient.find();
    res.status(200).json(ingredientss);
  } catch (err) {
    next(err);
  }
};